import NotFoundPage from "@/components/NotFoundPage";

const NotFound = () => {
  return <NotFoundPage />;
};

export default NotFound;
